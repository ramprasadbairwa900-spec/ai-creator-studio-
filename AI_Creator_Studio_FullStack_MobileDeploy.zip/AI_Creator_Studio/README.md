# AI Creator Studio — Full-stack starter

This package contains the responsive web/PWA frontend plus a FastAPI backend API.

## Start the API locally
1. Install Python 3.10+.
2. Open a terminal in `backend`.
3. Create a virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   # Windows: .venv\Scripts\activate
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env` and set a private `ADMIN_TOKEN`.
5. Run:
   ```bash
   uvicorn app.main:app --reload
   ```
6. Open `http://127.0.0.1:8000/docs` to test the API.

## Start frontend
Serve `frontend/` on localhost or HTTPS. Set `window.API_BASE` in `frontend/config.js` to your API URL. For a local test, use `http://127.0.0.1:8000`.

## API endpoints
- `GET /api/health` — health and provider mode
- `GET /api/config` — public app config and tools
- `POST /api/assets` — upload JPG/PNG/WEBP/MP4 (multipart field: `file`)
- `POST /api/jobs` — create a generation request (JSON: tool, prompt, style, asset_id)
- `GET /api/jobs/{job_id}` — check request status
- `GET /api/jobs` — list recent requests
- `GET /api/admin/summary` — protected admin counters (`X-Admin-Token` header)

## Important: AI generation status
The API is connected to the frontend and stores uploads and generation requests. It intentionally starts in `AI_PROVIDER=demo` mode. In this mode it does **not** claim that a video was generated. A real model adapter/worker must be added and configured for the selected image-to-video, text-to-video, speech, or animation model. Model inference may require paid API credits or a GPU; “free forever and unlimited” cannot be guaranteed.

Do not put provider keys in browser code. Keep them in backend environment variables. Before public launch add authentication, per-user quotas, rate limiting, content moderation, private storage, cleanup/retention policies, HTTPS, logging, backups, and abuse protection. The starter's upload endpoint is a development baseline, not a hardened public upload service.

## Android
The frontend is a PWA and can be installed from a supported Android browser when hosted over HTTPS. A Play Store Android package can be made later using Capacitor or a Trusted Web Activity and must be tested/signed separately.


## Deploy from Android phone (free starter)
1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository and upload the contents of this ZIP (keep folder structure).
3. Open Render in your phone browser and sign in.
4. Choose **New → Blueprint**, connect the GitHub repository, and let Render read `render.yaml`.
5. Review the service and choose the Free plan. Deploy.
6. Open the `onrender.com` URL after the deploy completes. The same URL serves the frontend and `/docs` serves API docs.

Free Render services sleep after 15 minutes without traffic and their local files are ephemeral; uploaded media and SQLite data may be lost on restart/redeploy. This is suitable for a test, not production. See https://render.com/docs/free.

## Free AI generation reality
The included API is a real upload/job API, but the renderer is intentionally not faked. It records requests as `waiting_for_provider` in demo mode. A free account can use some existing Hugging Face ZeroGPU Spaces with a limited daily GPU quota (currently 5 minutes/day for free users); this is not unlimited compute and does not guarantee that a chosen video model/API will be available or fast. Hosting your own ZeroGPU Space has eligibility and usage limits. See:
- https://huggingface.co/docs/hub/main/spaces-zerogpu
- https://huggingface.co/docs/hub/main/spaces-overview

Do not paste API tokens into frontend files or share them in chat. A real video-generation adapter should be connected server-side after selecting a model/provider and checking its current license, access policy, quota and cost.
