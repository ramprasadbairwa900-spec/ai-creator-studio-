window.API_BASE = ''; // Same-origin API: works locally and after one-service deployment.
