from __future__ import annotations
import os, uuid, sqlite3, json, mimetypes
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.getenv("DATA_DIR", ROOT / "data"))
UPLOADS = DATA / "uploads"
OUTPUTS = DATA / "outputs"
DB = DATA / "studio.db"
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "25"))
PROVIDER = os.getenv("AI_PROVIDER", "demo").lower()
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")

for folder in (DATA, UPLOADS, OUTPUTS):
    folder.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="AI Creator Studio API", version="1.0.0",
              description="Starter API for AI Creator Studio. AI rendering requires a configured provider.")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=False, allow_methods=["*"], allow_headers=["*"],
)
app.mount("/media/uploads", StaticFiles(directory=str(UPLOADS)), name="uploads")
app.mount("/media/outputs", StaticFiles(directory=str(OUTPUTS)), name="outputs")
STATIC_DIR = Path(__file__).resolve().parent / "static"

def connect():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS assets(
            id TEXT PRIMARY KEY, filename TEXT NOT NULL, content_type TEXT NOT NULL,
            size INTEGER NOT NULL, path TEXT NOT NULL, created_at TEXT NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS jobs(
            id TEXT PRIMARY KEY, tool TEXT NOT NULL, prompt TEXT NOT NULL, style TEXT NOT NULL,
            asset_id TEXT, status TEXT NOT NULL, provider TEXT NOT NULL, message TEXT NOT NULL,
            result_url TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")
init_db()

def now():
    return datetime.now(timezone.utc).isoformat()

class JobRequest(BaseModel):
    tool: str = Field(min_length=2, max_length=60)
    prompt: str = Field(min_length=2, max_length=3000)
    style: str = Field(default="3D Cartoon", max_length=80)
    asset_id: Optional[str] = None

@app.get("/api/health")
def health():
    return {"ok": True, "service":"AI Creator Studio API", "version":"1.0.0",
            "provider":PROVIDER, "generation_ready":PROVIDER != "demo"}

@app.post("/api/assets")
async def upload_asset(file: UploadFile = File(...)):
    allowed = {"image/jpeg","image/png","image/webp","video/mp4"}
    content_type = (file.content_type or "").lower()
    if content_type not in allowed:
        raise HTTPException(415, "Only JPG, PNG, WEBP and MP4 files are accepted.")
    raw = await file.read((MAX_UPLOAD_MB * 1024 * 1024) + 1)
    if not raw:
        raise HTTPException(400, "The uploaded file is empty.")
    if len(raw) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"File exceeds {MAX_UPLOAD_MB} MB limit.")
    ext = mimetypes.guess_extension(content_type) or ".bin"
    asset_id = uuid.uuid4().hex
    safe_name = asset_id + ext
    dest = UPLOADS / safe_name
    dest.write_bytes(raw)
    created = now()
    with connect() as con:
        con.execute("INSERT INTO assets VALUES(?,?,?,?,?,?)",
                    (asset_id, file.filename or safe_name, content_type, len(raw), str(dest), created))
    return {"asset_id":asset_id, "filename":file.filename, "content_type":content_type,
            "size":len(raw), "url":f"/media/uploads/{safe_name}"}

@app.post("/api/jobs", status_code=202)
def create_job(body: JobRequest):
    if body.asset_id:
        with connect() as con:
            asset = con.execute("SELECT id FROM assets WHERE id=?", (body.asset_id,)).fetchone()
        if not asset:
            raise HTTPException(404, "Uploaded asset was not found.")
    job_id = uuid.uuid4().hex
    created = now()
    # Safe starter behavior: accept and persist jobs, but never pretend to render
    # when no real inference provider is configured.
    if PROVIDER == "demo":
        status = "waiting_for_provider"
        message = "Request saved. Configure an AI video provider/GPU worker to render the video."
    else:
        status = "provider_adapter_required"
        message = f"Provider '{PROVIDER}' is selected, but its model adapter is not configured yet."
    with connect() as con:
        con.execute("INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (job_id, body.tool, body.prompt, body.style, body.asset_id, status,
                     PROVIDER, message, None, created, created))
    return {"job_id":job_id, "status":status, "tool":body.tool,
            "message":message, "created_at":created,
            "status_url":f"/api/jobs/{job_id}"}

@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    with connect() as con:
        row = con.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Job not found.")
    return dict(row)

@app.get("/api/jobs")
def list_jobs(limit: int = 20):
    limit = max(1, min(limit, 100))
    with connect() as con:
        rows = con.execute("SELECT id,tool,prompt,style,status,provider,message,result_url,created_at,updated_at FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return {"items":[dict(r) for r in rows]}

@app.get("/api/admin/summary")
def admin_summary(x_admin_token: Optional[str] = Header(default=None)):
    if not ADMIN_TOKEN or x_admin_token != ADMIN_TOKEN:
        raise HTTPException(403, "Admin access is not configured or token is invalid.")
    with connect() as con:
        assets = con.execute("SELECT COUNT(*) n FROM assets").fetchone()["n"]
        jobs = con.execute("SELECT COUNT(*) n FROM jobs").fetchone()["n"]
        waiting = con.execute("SELECT COUNT(*) n FROM jobs WHERE status NOT IN ('completed','failed')").fetchone()["n"]
    return {"assets":assets, "jobs":jobs, "pending_or_blocked_jobs":waiting}

@app.get("/api/config")
def public_config():
    return {"app_name":"AI Creator Studio", "max_upload_mb":MAX_UPLOAD_MB,
            "provider_mode":PROVIDER, "demo_mode":PROVIDER == "demo",
            "tools":["Photo to Dance","Cartoon Video","Text to Video","Talking Photo",
                     "Story Maker","AI Voice","Video Editor","Reels & Shorts","Image Creator"]}

# Serve the PWA frontend from the same host as the API (Render single-service deployment).
app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="frontend")
